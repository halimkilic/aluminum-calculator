// Alüminyum Hesaplama Eklentisi için JavaScript kodları
jQuery(document).ready(function($) {
    // Profil seçimi
    $('.aluminyum-profil-item').click(function() {
        // Aktif sınıfını kaldır
        $('.aluminyum-profil-item').removeClass('active');
        
        // Tıklanan öğeye aktif sınıfını ekle
        $(this).addClass('active');
        
        // Seçilen profil bilgisini al ve gizli alana kaydet
        var profilTipi = $(this).data('profil');
        $('#secilen-profil').val(profilTipi);
        
        // Profil tipine göre form alanlarını güncelle
        guncelleFormAlanlari(profilTipi);
    });
    
    // Özgül ağırlık değişimi
    $('#malzeme-ozgul-agirlik').change(function() {
        var yeniOzgulAgirlik = $(this).val();
        $('#ozgul-agirlik').val(yeniOzgulAgirlik);
    });
    
    // Formu temizle
    $('#formu-temizle-btn').click(function() {
        // Form alanlarını sıfırla
        $('#aluminyum-hesaplama-form')[0].reset();
        
        // Aktif profil seçimini kaldır
        $('.aluminyum-profil-item').removeClass('active');
        
        // Sonuç alanını sıfırla
        $('#teorik-agirlik').text('Teorik Ağırlık: 0.000 KG');
    });
    
    // Hesaplama işlemi
    $('#hesapla-btn').click(function() {
        var secilenProfil = $('#secilen-profil').val();
        
        // Profil seçilmiş mi kontrol et
        if (secilenProfil === '') {
            alert('Lütfen önce bir profil tipi seçin!');
            return;
        }
        
        // Form verilerini al
        var genislik = parseFloat($('#genislik').val()) || 0;
        var uzunluk = parseFloat($('#uzunluk').val()) || 0;
        var kalinlik = parseFloat($('#kalinlik').val()) || 0;
        var adet = parseInt($('#adet').val()) || 1;
        var ozgulAgirlik = parseFloat($('#ozgul-agirlik').val()) || 2.71;
        
        // Gerekli alanlar doldurulmuş mu kontrol et
        if (genislik <= 0 || uzunluk <= 0 || (kalinlik <= 0 && secilenProfil !== 'levha' && secilenProfil !== 'kare_profil')) {
            alert('Lütfen tüm boyut değerlerini doğru şekilde doldurun!');
            return;
        }
        
        // AJAX ile hesaplama yap
        $.ajax({
            url: aluminyum_hesaplama.ajax_url,
            type: 'POST',
            data: {
                action: 'aluminyum_hesapla',
                nonce: aluminyum_hesaplama.nonce,
                profil_tip: secilenProfil,
                genislik: genislik,
                uzunluk: uzunluk,
                kalinlik: kalinlik,
                adet: adet,
                ozgul_agirlik: ozgulAgirlik
            },
            beforeSend: function() {
                // Hesaplama başladığında buton durumunu güncelle
                $('#hesapla-btn').prop('disabled', true).text('Hesaplanıyor...');
            },
            success: function(response) {
                if (response.success) {
                    // Sonucu göster
                    $('#teorik-agirlik').text('Teorik Ağırlık: ' + response.data.toplam_agirlik + ' KG');
                } else {
                    alert('Hesaplama sırasında bir hata oluştu!');
                }
            },
            error: function() {
                alert('Sunucu ile iletişim kurulamadı!');
            },
            complete: function() {
                // İşlem tamamlandığında buton durumunu geri al
                $('#hesapla-btn').prop('disabled', false).text('HESAPLA');
            }
        });
    });
    
    // Profil tipine göre form alanlarını güncelle
    function guncelleFormAlanlari(profilTipi) {
        // Tüm form alanlarını önce göster
        $('.form-group').show();
        
        // Profil tipine göre etiketleri ve görünürlüğü güncelle
        switch (profilTipi) {
            case 'levha':
                $('#genislik').attr('placeholder', 'Genişlik (mm)');
                $('label[for="genislik"]').text('GENİŞLİK [d] - [mm]');
                $('#uzunluk').attr('placeholder', 'Uzunluk (mm)');
                $('label[for="uzunluk"]').text('UZUNLUK [b] - [mm]');
                $('#kalinlik').attr('placeholder', 'Kalınlık (mm)');
                $('label[for="kalinlik"]').text('KALINLIK [g] - [mm]');
                break;
                
            case 'u_profil':
                $('#genislik').attr('placeholder', 'Genişlik (mm)');
                $('label[for="genislik"]').text('GENİŞLİK [d] - [mm]');
                $('#uzunluk').attr('placeholder', 'Yükseklik (mm)');
                $('label[for="uzunluk"]').text('YÜKSEKLİK [b] - [mm]');
                $('#kalinlik').attr('placeholder', 'Et Kalınlığı (mm)');
                $('label[for="kalinlik"]').text('ET KALINLIĞI [g] - [mm]');
                break;
                
            case 'dolu_cubuk':
                $('#genislik').attr('placeholder', 'Çap (mm)');
                $('label[for="genislik"]').text('ÇAP [d] - [mm]');
                $('#uzunluk').attr('placeholder', 'Uzunluk (mm)');
                $('label[for="uzunluk"]').text('UZUNLUK [b] - [mm]');
                // Kalınlık alanını gizle
                $('label[for="kalinlik"]').parent().hide();
                break;
                
            case 'lama':
                $('#genislik').attr('placeholder', 'Genişlik (mm)');
                $('label[for="genislik"]').text('GENİŞLİK [d] - [mm]');
                $('#uzunluk').attr('placeholder', 'Uzunluk (mm)');
                $('label[for="uzunluk"]').text('UZUNLUK [b] - [mm]');
                $('#kalinlik').attr('placeholder', 'Kalınlık (mm)');
                $('label[for="kalinlik"]').text('KALINLIK [g] - [mm]');
                break;
                
            case 'kare_profil':
                $('#genislik').attr('placeholder', 'Kenar Uzunluğu (mm)');
                $('label[for="genislik"]').text('KENAR UZUNLUĞU [d] - [mm]');
                $('#uzunluk').attr('placeholder', 'Boy (mm)');
                $('label[for="uzunluk"]').text('BOY [b] - [mm]');
                // Kalınlık alanını gizle
                $('label[for="kalinlik"]').parent().hide();
                break;
                
            case 'aluminyum_kosebent':
                $('#genislik').attr('placeholder', 'Genişlik 1 (mm)');
                $('label[for="genislik"]').text('GENİŞLİK 1 [d] - [mm]');
                $('#uzunluk').attr('placeholder', 'Genişlik 2 (mm)');
                $('label[for="uzunluk"]').text('GENİŞLİK 2 [b] - [mm]');
                $('#kalinlik').attr('placeholder', 'Kalınlık (mm)');
                $('label[for="kalinlik"]').text('KALINLIK [g] - [mm]');
                break;
                
            case 'aluminyum_dikdortgen_profil':
                $('#genislik').attr('placeholder', 'Genişlik (mm)');
                $('label[for="genislik"]').text('GENİŞLİK [d] - [mm]');
                $('#uzunluk').attr('placeholder', 'Yükseklik (mm)');
                $('label[for="uzunluk"]').text('YÜKSEKLİK [b] - [mm]');
                $('#kalinlik').attr('placeholder', 'Et Kalınlığı (mm)');
                $('label[for="kalinlik"]').text('ET KALINLIĞI [g] - [mm]');
                break;
                
            case 'aluminyum_boru_profil':
                $('#genislik').attr('placeholder', 'Dış Çap (mm)');
                $('label[for="genislik"]').text('DIŞ ÇAP [d] - [mm]');
                $('#uzunluk').attr('placeholder', 'Uzunluk (mm)');
                $('label[for="uzunluk"]').text('UZUNLUK [b] - [mm]');
                $('#kalinlik').attr('placeholder', 'Duvar Kalınlığı (mm)');
                $('label[for="kalinlik"]').text('DUVAR KALINLIĞI [g] - [mm]');
                break;
                
            case 'aluminyum_kare_kutu_profil':
                $('#genislik').attr('placeholder', 'Kenar Uzunluğu (mm)');
                $('label[for="genislik"]').text('KENAR UZUNLUĞU [d] - [mm]');
                $('#uzunluk').attr('placeholder', 'Boy (mm)');
                $('label[for="uzunluk"]').text('BOY [b] - [mm]');
                $('#kalinlik').attr('placeholder', 'Et Kalınlığı (mm)');
                $('label[for="kalinlik"]').text('ET KALINLIĞI [g] - [mm]');
                break;
                
            case 'aluminyum_t_profil':
                $('#genislik').attr('placeholder', 'Flanş Genişliği (mm)');
                $('label[for="genislik"]').text('FLANŞ GENİŞLİĞİ [d] - [mm]');
                $('#uzunluk').attr('placeholder', 'Toplam Yükseklik (mm)');
                $('label[for="uzunluk"]').text('TOPLAM YÜKSEKLİK [b] - [mm]');
                $('#kalinlik').attr('placeholder', 'Et Kalınlığı (mm)');
                $('label[for="kalinlik"]').text('ET KALINLIĞI [g] - [mm]');
                break;
        }
    }
});