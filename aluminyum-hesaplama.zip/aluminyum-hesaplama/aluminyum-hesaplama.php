<?php
/**
 * Plugin Name: Alüminyum Profil Hesaplama
 * Plugin URI: https://wptr.com
 * Description: Alüminyum profil tipine göre ağırlık hesaplama yapan WordPress eklentisi
 * Version: 1.0
 * Author: Halim KILIÇ
 * Author URI: https://wptr.com
 * Text Domain: aluminyum-hesaplama
 */

// Güvenlik kontrolü
if (!defined('ABSPATH')) {
    exit;
}

class Aluminyum_Hesaplama {
    
    // Sınıf özellikleri
    private $plugin_path;
    private $plugin_url;
    
    // Sınıf başlatıcı
    public function __construct() {
        $this->plugin_path = plugin_dir_path(__FILE__);
        $this->plugin_url = plugin_dir_url(__FILE__);
        
        // Kancaları ekle
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_shortcode('aluminyum_hesaplama', array($this, 'hesaplama_formu_goster'));
        
        // Ayar sayfası ekle
        add_action('admin_menu', array($this, 'admin_menu_ekle'));
        
        // AJAX işlemleri
        add_action('wp_ajax_aluminyum_hesapla', array($this, 'hesapla'));
        add_action('wp_ajax_nopriv_aluminyum_hesapla', array($this, 'hesapla'));
    }
    
    // Script ve Stilleri Yükle
    public function enqueue_scripts() {
        // CSS dosyasını ekle
        wp_enqueue_style('aluminyum-hesaplama-css', $this->plugin_url . 'assets/css/style.css', array(), '1.0.0');
        
        // JavaScript dosyasını ekle
        wp_enqueue_script('aluminyum-hesaplama-js', $this->plugin_url . 'assets/js/script.js', array('jquery'), '1.0.0', true);
        
        // AJAX için gerekli verileri ekle
        wp_localize_script('aluminyum-hesaplama-js', 'aluminyum_hesaplama', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('aluminyum_hesaplama_nonce')
        ));
    }
    
    // Admin Menü
    public function admin_menu_ekle() {
        add_menu_page(
            'Alüminyum Hesaplama Ayarları',
            'Alüminyum Hesaplama',
            'manage_options',
            'aluminyum-hesaplama',
            array($this, 'admin_sayfa_icerik'),
            'dashicons-calculator',
            20
        );
    }
    
    // Admin Sayfa İçeriği
    public function admin_sayfa_icerik() {
        // Admin panel ayarları
        ?>
        <div class="wrap">
            <h1>Alüminyum Profil Hesaplama Ayarları</h1>
            <form method="post" action="options.php">
                <?php
                settings_fields('aluminyum_hesaplama_ayarlar');
                do_settings_sections('aluminyum_hesaplama_ayarlar');
                ?>
                <table class="form-table">
                    <tr>
                        <th scope="row">Kısa Kod</th>
                        <td><code>[aluminyum_hesaplama]</code> - Bu kodu herhangi bir sayfa veya yazıda kullanabilirsiniz.</td>
                    </tr>
                </table>
                <p>Bu eklenti sayesinde kullanıcılar seçtikleri alüminyum profil tipine göre ağırlık hesaplaması yapabilirler.</p>
            </form>
        </div>
        <?php
    }
    
    // Hesaplama İşlemi
    public function hesapla() {
        // Güvenlik kontrolü
        check_ajax_referer('aluminyum_hesaplama_nonce', 'nonce');
        
        // Gelen verileri al
        $profil_tip = sanitize_text_field($_POST['profil_tip']);
        $genislik = floatval($_POST['genislik']);
        $uzunluk = floatval($_POST['uzunluk']);
        $kalinlik = floatval($_POST['kalinlik']);
        $adet = intval($_POST['adet']);
        $ozgul_agirlik = floatval($_POST['ozgul_agirlik']);
        
        // Hesaplama işlemi
        $agirlik = 0;
        
        switch ($profil_tip) {
            case 'levha':
                // Levha ağırlık hesaplama formülü: genişlik * uzunluk * kalınlık * özgül ağırlık / 1000000
                $agirlik = ($genislik * $uzunluk * $kalinlik * $ozgul_agirlik) / 1000000;
                break;
                
            case 'u_profil':
                // U profil hesaplama formülü
                $ic_genislik = $genislik - (2 * $kalinlik);
                $agirlik = (($genislik * $uzunluk) - ($ic_genislik * ($uzunluk - $kalinlik))) * $kalinlik * $ozgul_agirlik / 1000000;
                break;
                
            case 'dolu_cubuk':
                // Dolu çubuk (silindir) hesaplama formülü: π * (çap/2)² * uzunluk * özgül ağırlık / 1000000
                $agirlik = M_PI * pow(($genislik / 2), 2) * $uzunluk * $ozgul_agirlik / 1000000;
                break;
                
            case 'lama':
                // Lama hesaplama formülü: genişlik * kalınlık * uzunluk * özgül ağırlık / 1000000
                $agirlik = $genislik * $kalinlik * $uzunluk * $ozgul_agirlik / 1000000;
                break;
                
            case 'kare_profil':
                // Kare profil hesaplama formülü: genişlik * genişlik * uzunluk * özgül ağırlık / 1000000
                $agirlik = $genislik * $genislik * $uzunluk * $ozgul_agirlik / 1000000;
                break;
                
            case 'aluminyum_kosebent':
                // Köşebent hesaplama formülü
                $agirlik = (($genislik * $kalinlik) + ($uzunluk * $kalinlik) - ($kalinlik * $kalinlik)) * $uzunluk * $ozgul_agirlik / 1000000;
                break;
                
            case 'aluminyum_dikdortgen_profil':
                // Dikdörtgen profil hesaplama formülü
                $ic_genislik = $genislik - (2 * $kalinlik);
                $ic_uzunluk = $uzunluk - (2 * $kalinlik);
                $agirlik = (($genislik * $uzunluk) - ($ic_genislik * $ic_uzunluk)) * $ozgul_agirlik / 1000;
                break;
                
            case 'aluminyum_boru_profil':
                // Boru profil hesaplama formülü: π * ((dış çap/2)² - (iç çap/2)²) * uzunluk * özgül ağırlık / 1000000
                $ic_cap = $genislik - (2 * $kalinlik);
                $agirlik = M_PI * (pow(($genislik / 2), 2) - pow(($ic_cap / 2), 2)) * $uzunluk * $ozgul_agirlik / 1000000;
                break;
                
            case 'aluminyum_kare_kutu_profil':
                // Kare kutu profil hesaplama formülü
                $ic_genislik = $genislik - (2 * $kalinlik);
                $agirlik = (($genislik * $genislik) - ($ic_genislik * $ic_genislik)) * $uzunluk * $ozgul_agirlik / 1000000;
                break;
                
            case 'aluminyum_t_profil':
                // T profil hesaplama formülü
                $agirlik = (($genislik * $kalinlik) + (($uzunluk - $kalinlik) * $kalinlik)) * $ozgul_agirlik * $uzunluk / 1000000;
                break;
        }
        
        // Toplam ağırlık (adet ile çarpım)
        $toplam_agirlik = $agirlik * $adet;
        
        // Sonucu döndür
        wp_send_json_success(array(
            'birim_agirlik' => number_format($agirlik, 3, ',', '.'),
            'toplam_agirlik' => number_format($toplam_agirlik, 3, ',', '.'),
        ));
        
        wp_die();
    }
    
    // Hesaplama Formunu Göster
    public function hesaplama_formu_goster() {
        ob_start();
        ?>
        <div class="aluminyum-hesaplama-container">
            <div class="aluminyum-hesaplama-row">
                <!-- Malzeme Şeklini Seçin -->
                <div class="aluminyum-hesaplama-col first-col">
                    <div class="aluminyum-hesaplama-card">
                        <h3>Malzeme Şeklini Seçin</h3>
                        <div class="aluminyum-profil-grid">
                            <div class="aluminyum-profil-item" data-profil="levha">
                                <div class="profil-image levha-img"></div>
                                <span>Levha</span>
                            </div>
                            <div class="aluminyum-profil-item" data-profil="u_profil">
                                <div class="profil-image u-profil-img"></div>
                                <span>U Profil</span>
                            </div>
                            <div class="aluminyum-profil-item" data-profil="dolu_cubuk">
                                <div class="profil-image dolu-cubuk-img"></div>
                                <span>Dolu Çubuk</span>
                            </div>
                            <div class="aluminyum-profil-item" data-profil="lama">
                                <div class="profil-image lama-img"></div>
                                <span>Lama</span>
                            </div>
                            <div class="aluminyum-profil-item" data-profil="kare_profil">
                                <div class="profil-image kare-profil-img"></div>
                                <span>Kare Profil</span>
                            </div>
                            <div class="aluminyum-profil-item" data-profil="aluminyum_kosebent">
                                <div class="profil-image kosebent-img"></div>
                                <span>Köşebent</span>
                            </div>
                            <div class="aluminyum-profil-item" data-profil="aluminyum_dikdortgen_profil">
                                <div class="profil-image dikdortgen-profil-img"></div>
                                <span>Dikdörtgen Profil</span>
                            </div>
                            <div class="aluminyum-profil-item" data-profil="aluminyum_boru_profil">
                                <div class="profil-image boru-profil-img"></div>
                                <span>Boru Profil</span>
                            </div>
                            <div class="aluminyum-profil-item" data-profil="aluminyum_kare_kutu_profil">
                                <div class="profil-image kare-kutu-profil-img"></div>
                                <span>Kare Kutu Profil</span>
                            </div>
                            <div class="aluminyum-profil-item" data-profil="aluminyum_t_profil">
                                <div class="profil-image t-profil-img"></div>
                                <span>T Profil</span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Seçenekleri Doldurun -->
                <div class="aluminyum-hesaplama-col">
                    <div class="aluminyum-hesaplama-card">
                        <h3>Seçenekleri Doldurun</h3>
                        <form id="aluminyum-hesaplama-form">
                            <div class="form-group">
                                <label for="genislik">GENİŞLİK [d] - [mm]</label>
                                <input type="number" id="genislik" name="genislik" placeholder="0" step="0.01" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="uzunluk">UZUNLUK [b] - [mm]</label>
                                <input type="number" id="uzunluk" name="uzunluk" placeholder="0" step="0.01" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="kalinlik">KALINLIK [g] - [mm]</label>
                                <input type="number" id="kalinlik" name="kalinlik" placeholder="0" step="0.01" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="adet">ADET</label>
                                <input type="number" id="adet" name="adet" value="1" min="1" required>
                            </div>
                            
                            <div class="form-group">
                                <button type="button" id="hesapla-btn">HESAPLA</button>
                                <button type="button" id="formu-temizle-btn">FORMU TEMİZLE</button>
                            </div>
                            
                            <input type="hidden" id="secilen-profil" name="secilen-profil" value="">
                            <input type="hidden" id="ozgul-agirlik" name="ozgul-agirlik" value="2.71">
                        </form>
                    </div>
                </div>
                
                <!-- Özgül Ağırlık -->
                <div class="aluminyum-hesaplama-col">
                    <div class="aluminyum-hesaplama-card">
                        <h3>Özgül Ağırlık</h3>
                        <div class="form-group">
                            <label for="malzeme-ozgul-agirlik">MALZEMENİN ÖZGÜL AĞIRLIĞI</label>
                            <select id="malzeme-ozgul-agirlik">
                                <option value="2.71" selected>2.71</option>
                                <option value="2.75">2.75</option>
                                <option value="2.80">2.80</option>
                                <option value="2.85">2.85</option>
                            </select>
                        </div>
                        
                        <div class="profil-boyut-diagram">
                            <img src="<?php echo $this->plugin_url; ?>assets/images/diagram.svg" alt="Profil Boyut Diyagramı">
                        </div>
                        
                        <div class="sonuc-kutusu">
                            <h3 id="teorik-agirlik">Teorik Ağırlık: 0.000 KG</h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
}

// Eklentiyi başlat
$aluminyum_hesaplama = new Aluminyum_Hesaplama();

// Aktivasyon işlemi
register_activation_hook(__FILE__, 'aluminyum_hesaplama_aktivasyon');

function aluminyum_hesaplama_aktivasyon() {
    // Gerekli klasörleri oluştur
    if (!file_exists(plugin_dir_path(__FILE__) . 'assets')) {
        mkdir(plugin_dir_path(__FILE__) . 'assets');
    }
    
    if (!file_exists(plugin_dir_path(__FILE__) . 'assets/css')) {
        mkdir(plugin_dir_path(__FILE__) . 'assets/css');
    }
    
    if (!file_exists(plugin_dir_path(__FILE__) . 'assets/js')) {
        mkdir(plugin_dir_path(__FILE__) . 'assets/js');
    }
    
    if (!file_exists(plugin_dir_path(__FILE__) . 'assets/images')) {
        mkdir(plugin_dir_path(__FILE__) . 'assets/images');
    }
}

// Deaktivasyon işlemi
register_deactivation_hook(__FILE__, 'aluminyum_hesaplama_deaktivasyon');

function aluminyum_hesaplama_deaktivasyon() {
    // Temizleme işlemleri burada yapılabilir
}